String CSR_Cred = "Ns+AA}V_";
