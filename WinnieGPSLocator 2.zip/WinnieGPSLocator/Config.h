String CSR_Cred = "^6]7Q5}o";
